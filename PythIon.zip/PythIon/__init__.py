'''
PythIon Nanopore Analysis
Written By: Robert Henley
Contributors: Dr. Spencer Carson

'''

__version__ = '0.2.0'

import Pythion
Pythion.start()