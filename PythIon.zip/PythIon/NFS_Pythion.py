#!/usr/bin/python
# -*- coding: utf8 -*-
import sys
import numpy as np
from scipy import ndimage
import os
from scipy import signal
from scipy import io as spio
from nfsplotgui import *
import pyqtgraph as pg
import pandas.io.parsers
import pandas as pd
from abfheader import *
from CUSUMV2 import detect_cusum
from PoreSizer import *
from batchinfo import *
import loadmat
import scipy as sp



class GUIForm(QtGui.QMainWindow):


    def __init__(self, width, height, master=None):
        ####Setup GUI and draw elements from UI file#########
        QtGui.QMainWindow.__init__(self,master)
        self.ui = Ui_PythIon()
        self.ui.setupUi(self)
        
        self.resize(.9*width,.9*height)
#        for widget in self.children():
#            print widget.children.children()
        
        ##########Linking buttons to main functions############
        self.ui.loadbutton.clicked.connect(self.getfile)
        self.ui.analyzebutton.clicked.connect(self.analyze)
        self.ui.cutbutton.clicked.connect(self.cut)
        self.ui.clearscatterbutton.clicked.connect(self.clearscatter)
        self.ui.deleteeventbutton.clicked.connect(self.deleteevent)
        self.ui.invertbutton.clicked.connect(self.invertdata)
        self.ui.actionConcatenate.triggered.connect(self.concatenatetext)
        self.ui.nextfilebutton.clicked.connect(self.nextfile)
        self.ui.previousfilebutton.clicked.connect(self.previousfile)
        self.ui.gobutton.clicked.connect(self.inspectevent)
        self.ui.previousbutton.clicked.connect(self.previousevent)
        self.ui.nextbutton.clicked.connect(self.nextevent)
        self.ui.Poresizeraction.triggered.connect(self.sizethepore)


        ###### Setting up plotting elements and their respective options######
        self.ui.signalplot.setBackground('w')
        self.ui.scatterplot.setBackground('w')
        self.ui.eventplot.setBackground('w')
        self.ui.rvhistplot.setBackground('w')
        self.ui.lifetimehistplot.setBackground('w')

        self.p1 = self.ui.signalplot.addPlot()
        self.p1.setLabel('bottom', text='Time', units='s')
        self.p1.setLabel('left', text='Current', units='A')
        self.p1.enableAutoRange(axis = 'x')
        self.p1.setDownsampling(ds=True, auto=True, mode='peak')


        self.w1 = self.ui.scatterplot.addPlot()
        self.p2 = pg.ScatterPlotItem()
        self.p2.sigClicked.connect(self.clicked)
        self.w1.addItem(self.p2)
        self.w1.setLabel('left', text='Lifetime', units=u'ms')
        self.w1.setLabel('bottom', text='Rupture Voltage', units=u'mV')
        self.w1.setLogMode(y=True,x=False)
        self.w1.showGrid(x=True, y=True)
        self.cb = pg.ColorButton(self.ui.scatterplot, color=(0,0,255,50))
#        self.cb.setFixedHeight(30)
#        self.cb.setFixedWidth(30)
#        print(self.ui.scattertab.geometry())
        self.cb.move(0,210)
        self.cb.show()

        self.w2 = self.ui.rvhistplot.addPlot()
        self.w2.setLabel('bottom', text='Rupture Voltage',units=u'mV')
        self.w2.setLabel('left', text='Counts')

        self.w3 = self.ui.lifetimehistplot.addPlot()
        self.w3.setLabel('bottom', text='Log(Lifetime)', units=u'ms')
        self.w3.setLabel('left', text='Counts')

        self.p3 = self.ui.eventplot.addPlot()
        self.p3.hideAxis('bottom')
        self.p3.hideAxis('left')

        dir_path = os.path.dirname(os.path.realpath(__file__))
        self.logo=ndimage.imread(dir_path + os.sep + "pythionlogo.png")
        self.logo=np.rot90(self.logo,-1)
        self.logo = pg.ImageItem(self.logo)
        self.p3.addItem(self.logo)
        self.p3.setAspectLocked(True)


        ####### Initializing various variables used for analysis##############
        self.direc=[]
        self.lr=[]
        self.lastevent=[]
        self.lastClicked=[]
        self.lastevent=0
        self.colors=[]
        self.sdf = pd.DataFrame(columns = ['fn','color','rupturevoltage',
                                           'lifetime'])
        
#        print(self.ui.scatterplot.geometry())

    def Load(self, loadandplot = True):
        self.catdata=[]
        self.batchinfo = pd.DataFrame(columns = list(['cutstart', 'cutend']))
        self.p3.clear()
        self.p3.setLabel('bottom', text='Current', units='A', unitprefix = 'n')
        self.p3.setLabel('left', text='', units = 'Counts')
        self.p3.setAspectLocked(False)

        colors = np.array(self.sdf.color)
        for i in range(len(colors)):
            colors[i] = pg.Color(colors[i])

        self.p2.setBrush(colors, mask=None)

        self.ui.eventinfolabel.clear()
        self.ui.eventcounterlabel.clear()
        self.ui.meandelilabel.clear()
        self.ui.meandwelllabel.clear()
        self.ui.meandtlabel.clear()
        self.totalplotpoints=len(self.p2.data)
        self.ui.eventnumberentry.setText(str(0))



        self.ui.filelabel.setText(self.datafilename)
        print(self.datafilename)
        self.LPfiltercutoff = np.float64(self.ui.LPentry.text())*1000
        self.outputsamplerate = np.float64(self.ui.outputsamplerateentry.text())*1000 #use integer multiples of 4166.67 ie 2083.33 or 1041.67


        if str(os.path.splitext(self.datafilename)[1])=='.opt':
            self.data = np.fromfile(self.datafilename, dtype = np.dtype('>d'))
            self.matfilename = str(os.path.splitext(self.datafilename)[0])  
            
            matfile = os.path.basename(self.matfilename)
            self.mat = loadmat.loadmat(self.matfilename+"_inf")[matfile]
            samplerate = np.float64(self.mat['samplerate'])
            filtrate = np.float64(self.mat['filterfreq']*1000)
            self.potential = np.float64(self.mat['potential'])
            self.pre_trigger_time_ms = np.float64(self.mat['pretrigger_time'])
            self.post_trigger_time_ms = np.float64(self.mat['posttrigger_time'])
            
            trigger_data = self.mat['triggered_pulse']
            self.start_voltage = trigger_data[0].initial_value
            self.final_voltage = trigger_data[0].ramp_target_value
            self.ramp_duration_ms = trigger_data[0].duration
            self.eject_voltage = trigger_data[1].initial_value
            self.eject_duration_ms = np.float64(trigger_data[1].duration)
 
            if samplerate < self.outputsamplerate:
                print("data sampled at lower rate than requested, reverting to original sampling rate")
                self.ui.outputsamplerateentry.setText(str((round(samplerate)/1000)))
                self.outputsamplerate = samplerate
                
            elif self.outputsamplerate > 250e3:
                    print('sample rate can not be >250kHz for axopatch files, displaying with a rate of 250kHz')
                    self.outputsamplerate  = 250e3


            if self.LPfiltercutoff >= filtrate:
                print('Already LP filtered lower than or at entry, data will not be filtered')
                self.LPfiltercutoff  = filtrate
                self.ui.LPentry.setText(str((round(self.LPfiltercutoff)/1000)))
                
            elif self.LPfiltercutoff < 100e3:
                Wn = round(self.LPfiltercutoff/(100*10**3/2),4)
                b,a = signal.bessel(4, Wn, btype='low');
                self.data = signal.filtfilt(b,a,self.data)
            else:
                print('Filter value too high, data not filtered')

                
        medfiltkernel = int(self.ui.medfiltentry.text())
        self.data = signal.medfilt(self.data,kernel_size=medfiltkernel)

        self.t=np.arange(0,len(self.data))
        self.t=self.t/self.outputsamplerate


        self.p1.clear()
        self.p1.setDownsampling(ds = True)
        #skips plotting first and last two points, there was a weird spike issue
        self.p1.plot(self.t[2:][:-2],self.data[2:][:-2],pen='b')

        self.p1.autoRange()

        self.p3.clear()
        aphy, aphx = np.histogram(self.data, bins = 1000)
        aphhist = pg.PlotCurveItem(aphx, aphy, stepMode=True, fillLevel=0, brush='b')
        self.p3.addItem(aphhist)
        self.p3.setXRange(np.min(self.data), np.max(self.data))
            

    def getfile(self):

        try:
            ######## attempt to open dialog from most recent directory########
            self.datafilename = QtWidgets.QFileDialog.getOpenFileName(self,'Open file',self.direc,("*.log;*.opt;*.npy;*.abf"))[0]
            self.direc=os.path.dirname(self.datafilename)
            self.Load()
        except TypeError:
            ####### if no recent directory exists open from working directory##
            self.direc==[]
            self.datafilename = QtWidgets.QFileDialog.getOpenFileName(self, 'Open file',os.getcwd(),("*.log;*.opt;*.npy;*.abf"))[0]
            self.direc=os.path.dirname(self.datafilename)
            self.Load()
        except IOError:
            #### if user cancels during file selection, exit loop#############
            return
            

    def analyze(self):
        # Calculating total event time in seconds   
        self.total_event_time = (self.pre_trigger_time_ms + self.post_trigger_time_ms)/1000
        
        # Calculating the event length in number of points
        self.event_length = self.total_event_time * self.outputsamplerate
        
        # Calculating the total number of events
        self.num_of_events = np.int(len(self.data)/self.event_length)
        
        # Defining a list to store events 
        self.events = [0 for i in range(self.num_of_events)]
        
        # For loop to store event i in place i of our list
        for i in range(self.num_of_events):
            self.events[i] = self.data[int(i*self.event_length):int((i+1)*self.event_length)]
                      
        # Scaling values to units of number of points
        self.pre_trigger_time = self.pre_trigger_time_ms / 1000 * self.outputsamplerate
        self.ramp_duration = self.ramp_duration_ms / 1000 * self.outputsamplerate
        self.eject_duration = self.eject_duration_ms / 1000 * self.outputsamplerate
        
        # Calculating loading rate in mV/ms
        self.loading_rate = (self.final_voltage-self.start_voltage)/self.ramp_duration_ms
        
        #print event_length, pre_trigger_time, ramp_duration, eject_duration
        
        # Defining a list for ramping portions of each event
        self.ramping_events = [0 for i in range(self.num_of_events)]
        
        # Storing only the ramping portions of each event based on matfile values
        for i in range(self.num_of_events):
            self.ramping_events[i] = self.data[int(i*self.event_length+
                    self.pre_trigger_time):int((i+1)*self.event_length-self.eject_duration)]
        
        # Allocating lists for storing data for each event
        self.current_deriv = [0 for i in range(self.num_of_events)]
        self.rupture_time = [0 for i in range(self.num_of_events)]
        self.rupture_voltage = [0 for i in range(self.num_of_events)]
        self.voltage_probability = [0 for i in range(self.num_of_events)]
        self.lifetime_integral = [0 for i in range(self.num_of_events)]
        self.lifetime = [0 for i in range(self.num_of_events)]
        
        # Setting default values of tau0 and voltage_beta (for now)
        self.tau0 = 1000.000
        self.voltage_beta = 40.000
        
        # Defining a function to compute lifetime integrand for future step
        def lifetime_integrand(V):
            with np.errstate(over='raise'):
                try:
                    li = (1/(self.tau0*self.loading_rate))*np.exp(V/self.voltage_beta - self.voltage_beta/(self.tau0*self.loading_rate)*np.exp(V/self.voltage_beta)-1)
                except FloatingPointError:
                    li = (0.0)
            return li
        
        for i in range(self.num_of_events):
            # Compute the gradient (derivative) of the ramping events    
            self.current_deriv[i] = np.gradient(self.ramping_events[i])
            
            # Find the maximum value of the derivative distribution (rupture time)
            self.rupture_time[i] = np.argmax(self.current_deriv[i][250:int(self.ramp_duration)])
            
            # From the rupture time, compute the rupture voltage
            self.rupture_voltage[i] = self.rupture_time[i] / self.ramp_duration * (self.final_voltage-self.start_voltage) + self.start_voltage
            
            # Computes the probability of rupture at a particular voltage value    
            self.voltage_probability[i] = (1/(self.tau0*self.loading_rate))*np.exp(self.rupture_voltage[i]/self.voltage_beta - self.voltage_beta/(self.tau0*self.loading_rate)*(np.exp(self.rupture_voltage[i]/self.voltage_beta)-1))
        
            # Calculates the numerator of the lifetime value
            self.lifetime_integral[i] = sp.integrate.quad(lifetime_integrand,self.rupture_voltage[i],np.inf)
            if self.lifetime_integral[i] == (0.0, 0.0):
                self.lifetime[i] = np.NaN
            else:
                # Completes the calculation of the lifetime values for each event
                self.lifetime[i] = self.lifetime_integral[i][0]/(self.loading_rate*self.voltage_probability[i])   

            
        # Defining a list for time on plots to follow 
        self.time = np.arange(self.ramp_duration)
        self.time = self.time / self.outputsamplerate * 1000
            
        self.lifetime = np.array(self.lifetime)
        self.rupture_voltage = np.array(self.rupture_voltage)
#        self.ramping_events = np.array(self.ramping_events)
            
        self.rupture_voltage[np.isnan(self.lifetime)] = np.NaN
#        self.rupture_voltage = self.rupture_voltage[self.lifetime != 0]
#        self.ramping_events = self.ramping_events[self.lifetime != 0]
#        self.lifetime = self.lifetime[self.lifetime != 0]
#        self.num_of_events = len(self.lifetime)
        
        try:
            self.p2.data = self.p2.data[np.where(np.array(self.sdf.fn) != self.matfilename)]
        except:
            IndexError
        self.sdf = self.sdf[self.sdf.fn != self.matfilename]
        
        fn = pd.Series([self.matfilename,] * self.num_of_events)
        color = pd.Series([pg.colorTuple(self.cb.color()),] * self.num_of_events)

        
        self.sdf = self.sdf.append(pd.DataFrame({'fn':fn,'color':color,
            'rupturevoltage':self.rupture_voltage,'lifetime':self.lifetime}),
            ignore_index=True)


        self.p2.addPoints(x = self.rupture_voltage[~np.isnan(self.lifetime)],
                          y = self.lifetime[~np.isnan(self.lifetime)], 
                          symbol='o', brush=(self.cb.color()), 
                          pen = None, size = 10)


        self.w1.addItem(self.p2)
        self.w1.setLogMode(y=True,x=False)
        self.p1.autoRange()
        self.w1.autoRange()
        self.ui.scatterplot.update()

        self.ui.eventcounterlabel.setText('Events:'+str(self.num_of_events))
        self.ui.meandelilabel.setText('Rupture Voltage:'+str(round(
                    np.mean(self.rupture_voltage[~np.isnan(
                    self.rupture_voltage)]),2))+' mV')
        self.ui.meandwelllabel.setText('Lifetime:'+str(round(np.median
                    (self.lifetime[~np.isnan(self.lifetime)]),2))+ u' ms')        
        
        colors = self.sdf.color.unique()
        for i, x in enumerate(colors):
            rvhistvals = self.sdf.rupturevoltage[self.sdf.color == x]
            rvhistvals = rvhistvals[~np.isnan(rvhistvals)]
            rvy, rvx = np.histogram(rvhistvals,
                            bins=np.linspace(float(self.ui.rvrange0.text()),
                            float(self.ui.rvrange1.text()), 
                            int(self.ui.rvbins.text())))
            
#            lifetimehistvals = self.sdf.lifetime[self.sdf.color == x]
#            lifetimehistvals = lifetimehistvals[~np.isnan(lifetimehistvals)]
#            lifetimey, lifetimex = np.histogram(np.log10(lifetimehistvals),
#                            bins=np.linspace(float(self.ui.lifetimerange0.text()),
#                            float(self.ui.lifetimerange1.text()), 
#                            int(self.ui.lifetimebins.text())))

            hist = pg.BarGraphItem(height = rvy, x0 = rvx[:-1], x1 = rvx[1:], 
                            brush = x)
            self.w2.addItem(hist)
            self.w2.setRange(xRange = [float(self.ui.rvrange0.text()),
                            float(self.ui.rvrange1.text())])

#            hist = pg.BarGraphItem(height = lifetimey, x0 = lifetimex[:-1], 
#                                   x1 = lifetimex[1:], brush = x)
#            self.w3.addItem(hist)
#            self.w3.setRange(xRange = [float(self.ui.lifetimerange0.text()),
#                            float(self.ui.lifetimerange1.text())])
        
        
        # Saving rupture voltage and lifetime to datafile
        self.save()
    
    def save(self):
        x = np.array(self.rupture_time)[~np.isnan(self.lifetime)]
        x = 1000*np.array(x)/self.outputsamplerate
        print(x)
        np.savetxt(self.matfilename+'DB.txt', x, delimiter = '\t')    
  
    def inspectevent(self, clicked = []):

        #Reset plot
        self.p3.setLabel('bottom', text='Time', units='s')
        self.p3.setLabel('left', text='Current', units='A')
        self.p3.clear()

        #Correct for user error if non-extistent number is entered
        eventbuffer=np.int(self.ui.eventbufferentry.text())
        firstindex = self.sdf.fn[self.sdf.fn == self.matfilename].index[0]
        if clicked == []:
            eventnumber = np.int(self.ui.eventnumberentry.text())
        else:
            eventnumber = clicked - firstindex
            self.ui.eventnumberentry.setText(str(eventnumber))
        if eventnumber>=self.num_of_events:
            eventnumber=self.num_of_events-1
            self.ui.eventnumberentry.setText(str(eventnumber))

        #plot event trace
        x = self.t[int(eventnumber*self.event_length+self.pre_trigger_time):
            int((eventnumber+1)*self.event_length-self.eject_duration)]
        y = self.ramping_events[eventnumber]
        self.p3.plot(x,y, pen='b')
        
#        self.p3.plot(self.t[startpoints[eventnumber]-eventbuffer:endpoints[eventnumber]+eventbuffer],
#                     self.data[startpoints[eventnumber]-eventbuffer:endpoints[eventnumber]+eventbuffer], pen='b')

#        #plot event fit
#        self.p3.plot(self.t[startpoints[eventnumber]-eventbuffer:endpoints[eventnumber]+eventbuffer],np.concatenate((
#                     np.repeat(np.array([self.baseline]),eventbuffer),np.repeat(np.array([self.baseline-self.deli[eventnumber
#                     ]]),endpoints[eventnumber]-startpoints[eventnumber]),np.repeat(np.array([self.baseline]),eventbuffer)),0),pen=pg.mkPen(color=(173,27,183),width=3))
#
        self.p3.autoRange()
#        #Mark event that is being viewed on scatter plot
#
#        colors = np.array(self.sdf.color)
#        for i in range(len(colors)):
#            colors[i] = pg.Color(colors[i])
#        colors[firstindex + eventnumber] = pg.mkColor('r')
#
#        self.p2.setBrush(colors, mask=None)
#
#
        #Mark event start and end points
        if np.isnan(self.lifetime[eventnumber]):
            text = pg.TextItem(text = "Invalid Event", color = 'r')
            self.p3.addItem(text)
            text.setPos(x.min(), y.max())
            
        else:
            self.p3.plot([self.t[int(self.rupture_time[eventnumber]+eventnumber*self.event_length+250+self.pre_trigger_time)], 
                          self.t[int(self.rupture_time[eventnumber]+eventnumber*self.event_length+250+self.pre_trigger_time)]],
                          [self.data[int(self.rupture_time[eventnumber]+eventnumber*self.event_length+250+self.pre_trigger_time)], 
                           self.data[int(self.rupture_time[eventnumber]+eventnumber*self.event_length+250+self.pre_trigger_time)]],
                           pen=None, symbol='o',symbolBrush='g',symbolSize=12)
        
#        self.p3.plot([self.t[endpoints[eventnumber]], self.t[endpoints[eventnumber]]],[self.data[endpoints[eventnumber]], self.data[endpoints[eventnumber]]],pen=None, symbol='o',symbolBrush='r',symbolSize=12)
#
        self.ui.eventinfolabel.setText('Rupture Voltage=' + str(round(self.rupture_voltage[eventnumber],2))+ u' mV,   Lifetime='+str(round(self.lifetime[eventnumber],2)) +' ms')


    def nextevent(self):
        eventnumber=np.int(self.ui.eventnumberentry.text())

        if eventnumber>=self.num_of_events-1:
            eventnumber=0
        else:
            eventnumber=np.int(self.ui.eventnumberentry.text())+1
        self.ui.eventnumberentry.setText(str(eventnumber))
        self.inspectevent()

    def previousevent(self):

        eventnumber=np.int(self.ui.eventnumberentry.text())

        eventnumber=np.int(self.ui.eventnumberentry.text())-1
        if eventnumber<0:
            eventnumber=self.num_of_events-1
        self.ui.eventnumberentry.setText(str(eventnumber))
        self.inspectevent()

    def cut(self):
        
        ###### first check to see if cutting############

        if self.lr==[]:
            ######## if no cutting window exists, make one##########
            self.lr = pg.LinearRegionItem()
            self.lr.hide()

            ##### detect clears and auto-position window around the clear#####
            clears = np.where(np.abs(self.data) > self.baseline + 10*self.var)[0]
            if clears != []:
                clearstarts = clears[0]
                try:
                    clearends = clearstarts + np.where((self.data[clearstarts:-1] > self.baseline) &
                    (self.data[clearstarts:-1] < self.baseline+self.var))[0][10000]
                except:
                    clearends = -1
                clearstarts = np.where(self.data[0:clearstarts] > self.baseline)
                try:
                    clearstarts = clearstarts[0][-1]
                except:
                    clearstarts = 0

                self.lr.setRegion((self.t[clearstarts],self.t[clearends]))

            self.p1.addItem(self.lr)
            self.lr.show()


        #### if cut region has been set, cut region and replot remaining data####
        else:
            cutregion = self.lr.getRegion()
            self.p1.clear()
            self.data = np.delete(self.data,np.arange(np.int(cutregion[0]*self.outputsamplerate),np.int(cutregion[1]*self.outputsamplerate)))

            self.t=np.arange(0,len(self.data))
            self.t=self.t/self.outputsamplerate

            self.p1.plot(self.t,self.data,pen='b')

            self.lr=[]
#            self.p1.autoRange()
            self.p3.clear()
#            aphy, aphx = np.histogram(self.data, bins = len(self.data)/1000)
            aphy, aphx = np.histogram(self.data, bins = 1000)

            aphhist = pg.BarGraphItem(height = aphy, x0 = aphx[:-1], x1 = aphx[1:],brush = 'b', pen = None)
            self.p3.addItem(aphhist)
            self.p3.setXRange(np.min(self.data), np.max(self.data))
            
            cf = pd.DataFrame([cutregion], columns = list(['cutstart', 'cutend']))
            self.batchinfo = self.batchinfo.append(cf, ignore_index = True)



    def clearscatter(self):
        self.p2.setData(x=[],y=[])
        self.lastevent=[]
        self.ui.scatterplot.update()
        self.w2.clear()
        self.w3.clear()
        self.sdf = pd.DataFrame(columns = ['fn','color','rupturevoltage','lifetime'])

    def deleteevent(self):
        global startpoints,endpoints
        eventnumber = np.int(self.ui.eventnumberentry.text())
        firstindex = self.sdf.fn[self.sdf.fn == self.matfilename].index[0]
        if eventnumber > self.num_of_events:
            eventnumber = self.num_of_events-1
            self.ui.eventnumberentry.setText(str(eventnumber))
        self.rupture_voltage[eventnumber] = np.NaN
        self.lifetime[eventnumber] = np.NaN
        self.rupture_time[eventnumber] = np.NaN
#        self.ramping_events.pop(eventnumber)
        self.p2.data=np.delete(self.p2.data,firstindex + eventnumber)

        self.num_of_events = len(self.rupture_voltage)
        self.ui.eventcounterlabel.setText('Events:'+str(self.num_of_events))

        self.sdf = self.sdf.drop(firstindex + eventnumber).reset_index(drop = True)
        self.inspectevent() 

        self.w2.clear()
        self.w3.clear()
        colors = self.sdf.color.unique()
        for i, x in enumerate(colors):
            rvy, rvx = np.histogram(self.sdf.rupturevoltage[self.sdf.color == x], bins=np.linspace(float(self.ui.rvrange0.text()), float(self.ui.rvrange1.text()), int(self.ui.rvbins.text())))
#            dwelly, dwellx = np.histogram(np.log10(self.sdf.dwell[self.sdf.color == x]), bins=np.linspace(float(self.ui.dwellrange0.text()), float(self.ui.dwellrange1.text()), int(self.ui.dwellbins.text())))

            hist = pg.BarGraphItem(height = rvy, x0 = rvx[:-1], x1 = rvx[1:], brush = x)
            self.w2.addItem(hist)
#            self.w3.autoRange()
            self.w2.setRange(xRange = [float(self.ui.rvrange0.text()), float(self.ui.rvrange1.text())])
        
        
        
        # Saving rupture voltage and lifetime to datafile
        self.save()   


    def invertdata(self):
        self.p1.clear()
        self.data=-self.data

        if self.hasbaselinebeenset==0:
            self.baseline=np.median(self.data)
            self.var=np.std(self.data)

#        self.p1.plot(self.t[::10],self.data[::10],pen='b')
        self.p1.plot(self.t,self.data,pen='b')
        self.p1.addLine(y=self.baseline,pen='g')
        self.p1.addLine(y=self.threshold,pen='r')
        self.p1.autoRange()

    def clicked(self, plot, points):
        for i, p in enumerate(self.p2.points()):
            if p.pos() == points[0].pos():
                clickedindex = i

        if self.sdf.fn[clickedindex] != self.matfilename:
            print('Event is from an earlier file, not clickable')

        else:
            self.inspectevent(clickedindex)



    def concatenatetext(self):
        if self.direc==[]:
            textfilenames = QtGui.QFileDialog.getOpenFileNames(self, 'Open file','*.txt')[0]
            self.direc=os.path.dirname(textfilenames[0])
        else:
            textfilenames =QtGui.QFileDialog.getOpenFileNames(self, 'Open file',self.direc,'*.txt')[0]
            self.direc=os.path.dirname(textfilenames[0])
        i=0
        while i<len(textfilenames):
            temptextdata=np.fromfile(str(textfilenames[i]),sep='\t')
            temptextdata=np.reshape(temptextdata,(len(temptextdata)/4,4))
            if i==0:
                newtextdata=temptextdata
            else:
                newtextdata=np.concatenate((newtextdata,temptextdata))
            i=i+1

        newfilename = QtGui.QFileDialog.getSaveFileName(self, 'New File name',self.direc,'*.txt')[0]
        np.savetxt(str(newfilename),newtextdata,delimiter='\t')

    def nextfile(self):
        if str(os.path.splitext(self.datafilename)[1])=='.log':
            startindex=self.matfilename[-6::]
            filebase=self.matfilename[0:len(self.matfilename)-6]
            nextindex=str(int(startindex)+1)
            while os.path.isfile(filebase+nextindex+'.log')==False:
                nextindex=str(int(nextindex)+1)
                if int(nextindex)>int(startindex)+1000:
                    print('no such file')
                    break
            if os.path.isfile(filebase+nextindex+'.log')==True:
                self.datafilename=(filebase+nextindex+'.log')
                self.Load()

        if str(os.path.splitext(self.datafilename)[1])=='.abf':
            startindex=self.matfilename[-4::]
            filebase=self.matfilename[0:len(self.matfilename)-4]
            nextindex=str(int(startindex)+1).zfill(4)
            while os.path.isfile(filebase+nextindex+'.abf')==False:
                nextindex=str(int(nextindex)+1).zfill(4)
                if int(nextindex)>int(startindex)+1000:
                    print('no such file')
                    break
            if os.path.isfile(filebase+nextindex+'.abf')==True:
                self.datafilename=(filebase+nextindex+'.abf')
                self.Load()



    def previousfile(self):
        if str(os.path.splitext(self.datafilename)[1])=='.log':
            startindex=self.matfilename[-6::]
            filebase=self.matfilename[0:len(self.matfilename)-6]
            nextindex=str(int(startindex)-1)
            while os.path.isfile(filebase+nextindex+'.log')==False:
                nextindex=str(int(nextindex)-1)
                if int(nextindex)<int(startindex)-1000:
                    print('no such file')
                    break
            if os.path.isfile(filebase+nextindex+'.log')==True:
                self.datafilename=(filebase+nextindex+'.log')
                self.Load()

        if str(os.path.splitext(self.datafilename)[1])=='.abf':
            startindex=self.matfilename[-4::]
            filebase=self.matfilename[0:len(self.matfilename)-4]
            nextindex=str(int(startindex)-1).zfill(4)
            while os.path.isfile(filebase+nextindex+'.abf')==False:
                nextindex=str(int(nextindex)-1).zfill(4)
                if int(nextindex)<int(startindex)-1000:
                    print('no such file')
                    break
            if os.path.isfile(filebase+nextindex+'.abf')==True:
                self.datafilename=(filebase+nextindex+'.abf')
                self.Load()

    def savetrace(self):
        self.data.astype('d').tofile(self.matfilename+'_trace.bin')


    def keyPressEvent(self, event):
        key = event.key()
        if key == QtCore.Qt.Key_Up:
            self.nextfile()
        if key == QtCore.Qt.Key_Down:
            self.previousfile()
        if key == QtCore.Qt.Key_Right:
            self.nextevent()
        if key == QtCore.Qt.Key_Left:
            self.previousevent()
        if key == QtCore.Qt.Key_Return:
            self.Load()
        if key == QtCore.Qt.Key_Space:
            self.analyze()
        if key == QtCore.Qt.Key_Delete:
            self.deleteevent()
        
        

    def sizethepore(self):
        self.ps = PoreSizer()
        self.ps.show()

def start():
    global myapp
    app = QtGui.QApplication(sys.argv)
    resolution = app.desktop().screenGeometry()
    width,height = resolution.width(), resolution.height()
    myapp = GUIForm(width=width, height=height)
    myapp.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    start()

